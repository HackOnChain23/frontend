const CoreHeader_vue_vue_type_style_index_0_lang = ".bg-violet_gradient{background:#4945fc;background:linear-gradient(90deg,#4945fc 1%,#06b6d4 150%)}";

const CoreHeaderStyles_abc22f7c = [CoreHeader_vue_vue_type_style_index_0_lang];

export { CoreHeaderStyles_abc22f7c as default };
//# sourceMappingURL=CoreHeader-styles.abc22f7c.mjs.map
