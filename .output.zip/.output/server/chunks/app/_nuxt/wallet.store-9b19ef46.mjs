import { d as defineStore, u as useState, a as useRouter } from '../server.mjs';
import Web3 from 'web3';

const contractAbi = [
  {
    inputs: [],
    stateMutability: "nonpayable",
    type: "constructor"
  },
  {
    inputs: [],
    name: "InvalidShortString",
    type: "error"
  },
  {
    inputs: [
      {
        internalType: "string",
        name: "str",
        type: "string"
      }
    ],
    name: "StringTooLong",
    type: "error"
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: "address",
        name: "owner",
        type: "address"
      },
      {
        indexed: true,
        internalType: "address",
        name: "approved",
        type: "address"
      },
      {
        indexed: true,
        internalType: "uint256",
        name: "tokenId",
        type: "uint256"
      }
    ],
    name: "Approval",
    type: "event"
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: "address",
        name: "owner",
        type: "address"
      },
      {
        indexed: true,
        internalType: "address",
        name: "operator",
        type: "address"
      },
      {
        indexed: false,
        internalType: "bool",
        name: "approved",
        type: "bool"
      }
    ],
    name: "ApprovalForAll",
    type: "event"
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: "uint256",
        name: "_fromTokenId",
        type: "uint256"
      },
      {
        indexed: false,
        internalType: "uint256",
        name: "_toTokenId",
        type: "uint256"
      }
    ],
    name: "BatchMetadataUpdate",
    type: "event"
  },
  {
    anonymous: false,
    inputs: [],
    name: "EIP712DomainChanged",
    type: "event"
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: false,
        internalType: "uint256",
        name: "_tokenId",
        type: "uint256"
      }
    ],
    name: "MetadataUpdate",
    type: "event"
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: "address",
        name: "previousOwner",
        type: "address"
      },
      {
        indexed: true,
        internalType: "address",
        name: "newOwner",
        type: "address"
      }
    ],
    name: "OwnershipTransferred",
    type: "event"
  },
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: "address",
        name: "from",
        type: "address"
      },
      {
        indexed: true,
        internalType: "address",
        name: "to",
        type: "address"
      },
      {
        indexed: true,
        internalType: "uint256",
        name: "tokenId",
        type: "uint256"
      }
    ],
    name: "Transfer",
    type: "event"
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "to",
        type: "address"
      },
      {
        internalType: "string",
        name: "partUri",
        type: "string"
      },
      {
        internalType: "uint16",
        name: "partNumber",
        type: "uint16"
      },
      {
        internalType: "uint256",
        name: "tokenId",
        type: "uint256"
      }
    ],
    name: "addPart",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "to",
        type: "address"
      },
      {
        internalType: "uint256",
        name: "tokenId",
        type: "uint256"
      }
    ],
    name: "approve",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "owner",
        type: "address"
      }
    ],
    name: "balanceOf",
    outputs: [
      {
        internalType: "uint256",
        name: "",
        type: "uint256"
      }
    ],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [],
    name: "eip712Domain",
    outputs: [
      {
        internalType: "bytes1",
        name: "fields",
        type: "bytes1"
      },
      {
        internalType: "string",
        name: "name",
        type: "string"
      },
      {
        internalType: "string",
        name: "version",
        type: "string"
      },
      {
        internalType: "uint256",
        name: "chainId",
        type: "uint256"
      },
      {
        internalType: "address",
        name: "verifyingContract",
        type: "address"
      },
      {
        internalType: "bytes32",
        name: "salt",
        type: "bytes32"
      },
      {
        internalType: "uint256[]",
        name: "extensions",
        type: "uint256[]"
      }
    ],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "uint256",
        name: "tokenId",
        type: "uint256"
      }
    ],
    name: "getApproved",
    outputs: [
      {
        internalType: "address",
        name: "",
        type: "address"
      }
    ],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "uint256",
        name: "tokenId",
        type: "uint256"
      }
    ],
    name: "getTokenDetails",
    outputs: [
      {
        components: [
          {
            internalType: "address",
            name: "creator",
            type: "address"
          },
          {
            internalType: "string",
            name: "dataTypes",
            type: "string"
          },
          {
            internalType: "address[]",
            name: "contributors",
            type: "address[]"
          },
          {
            internalType: "string[]",
            name: "uriParts",
            type: "string[]"
          },
          {
            internalType: "uint16",
            name: "partsAmount",
            type: "uint16"
          }
        ],
        internalType: "struct BlockArtistry.Token",
        name: "token",
        type: "tuple"
      }
    ],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "addr",
        type: "address"
      }
    ],
    name: "initRewardContract",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "owner",
        type: "address"
      },
      {
        internalType: "address",
        name: "operator",
        type: "address"
      }
    ],
    name: "isApprovedForAll",
    outputs: [
      {
        internalType: "bool",
        name: "",
        type: "bool"
      }
    ],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [],
    name: "name",
    outputs: [
      {
        internalType: "string",
        name: "",
        type: "string"
      }
    ],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [],
    name: "owner",
    outputs: [
      {
        internalType: "address",
        name: "",
        type: "address"
      }
    ],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "uint256",
        name: "tokenId",
        type: "uint256"
      }
    ],
    name: "ownerOf",
    outputs: [
      {
        internalType: "address",
        name: "",
        type: "address"
      }
    ],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [],
    name: "renounceOwnership",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function"
  },
  {
    inputs: [],
    name: "rewardToken",
    outputs: [
      {
        internalType: "contract IRewardToken",
        name: "",
        type: "address"
      }
    ],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "to",
        type: "address"
      },
      {
        internalType: "string",
        name: "dataTypes",
        type: "string"
      },
      {
        internalType: "string",
        name: "partUri",
        type: "string"
      },
      {
        internalType: "uint16",
        name: "partsAmount",
        type: "uint16"
      },
      {
        internalType: "uint16",
        name: "partToAdd",
        type: "uint16"
      }
    ],
    name: "safeMint",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "from",
        type: "address"
      },
      {
        internalType: "address",
        name: "to",
        type: "address"
      },
      {
        internalType: "uint256",
        name: "tokenId",
        type: "uint256"
      }
    ],
    name: "safeTransferFrom",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "from",
        type: "address"
      },
      {
        internalType: "address",
        name: "to",
        type: "address"
      },
      {
        internalType: "uint256",
        name: "tokenId",
        type: "uint256"
      },
      {
        internalType: "bytes",
        name: "data",
        type: "bytes"
      }
    ],
    name: "safeTransferFrom",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "operator",
        type: "address"
      },
      {
        internalType: "bool",
        name: "approved",
        type: "bool"
      }
    ],
    name: "setApprovalForAll",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "bytes4",
        name: "interfaceId",
        type: "bytes4"
      }
    ],
    name: "supportsInterface",
    outputs: [
      {
        internalType: "bool",
        name: "",
        type: "bool"
      }
    ],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [],
    name: "symbol",
    outputs: [
      {
        internalType: "string",
        name: "",
        type: "string"
      }
    ],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "uint256",
        name: "index",
        type: "uint256"
      }
    ],
    name: "tokenByIndex",
    outputs: [
      {
        internalType: "uint256",
        name: "",
        type: "uint256"
      }
    ],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "owner",
        type: "address"
      },
      {
        internalType: "uint256",
        name: "index",
        type: "uint256"
      }
    ],
    name: "tokenOfOwnerByIndex",
    outputs: [
      {
        internalType: "uint256",
        name: "",
        type: "uint256"
      }
    ],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "uint256",
        name: "tokenId",
        type: "uint256"
      }
    ],
    name: "tokenURI",
    outputs: [
      {
        internalType: "string",
        name: "",
        type: "string"
      }
    ],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [],
    name: "totalSupply",
    outputs: [
      {
        internalType: "uint256",
        name: "",
        type: "uint256"
      }
    ],
    stateMutability: "view",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "from",
        type: "address"
      },
      {
        internalType: "address",
        name: "to",
        type: "address"
      },
      {
        internalType: "uint256",
        name: "tokenId",
        type: "uint256"
      }
    ],
    name: "transferFrom",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function"
  },
  {
    inputs: [
      {
        internalType: "address",
        name: "newOwner",
        type: "address"
      }
    ],
    name: "transferOwnership",
    outputs: [],
    stateMutability: "nonpayable",
    type: "function"
  }
];
const useWalletStore = defineStore("wallet", () => {
  const walletAddress = useState("walletAddress");
  const contractResult = useState("contractResult");
  const connected = useState("connected");
  const loader = useState("loader");
  const tokens = useState("tokens");
  const parts = useState("parts");
  const tokenId = useState("tokenid");
  const getWeb3 = async () => {
    return new Promise(async (resolve, reject) => {
      const web3 = await new Web3(window.ethereum);
      try {
        await ethereum.request({ method: "eth_requestAccounts" });
        resolve(web3);
      } catch (err) {
        reject(err);
      }
    });
  };
  const connectWallet = async () => {
    const web3 = await getWeb3();
    const walletAddressMeta = await web3.eth.requestAccounts();
    walletAddress.value = walletAddressMeta[0];
    connected.value = true;
  };
  const callSmartContract = async (contractAddress, json) => {
    const web3 = new Web3(window.ethereum);
    let address = contractAddress;
    let abi = JSON.parse(json);
    console.log(address, json);
    let contract = await new web3.eth.Contract(abi, address);
    contract.methods.store(123456789).send({ from: walletAddress.value }).then((result) => {
      contractResult.value = result;
    });
  };
  const router = useRouter();
  const safeMintNft = async (contractAddress, json, url, index) => {
    const web3 = new Web3(window.ethereum);
    let address = contractAddress;
    let abi = json;
    let contract = await new web3.eth.Contract(abi, address);
    web3.eth.estimateGas({ from: walletAddress.value, gas: 5e6 }).then((res) => {
      console.log(res, "estimate");
    });
    const indexRender = index;
    console.log(indexRender, "hiahiahaiahi");
    contract.methods.safeMint(walletAddress.value, "image", url, 6, indexRender).send({ from: walletAddress.value, gas: 5e6 }).then((result) => {
      console.log(result);
      loader.value = false;
      router.push("/");
    }).catch(() => {
      loader.value = false;
    });
  };
  const join = async (json, url, position, id) => {
    const web3 = new Web3(window.ethereum);
    let address = "0x49a985C23CEda09d42AB7e4e3F78718404834b73";
    let abi = json;
    let contract = await new web3.eth.Contract(abi, address);
    console.log(
      json,
      abi,
      walletAddress.value,
      url,
      position,
      id,
      typeof position,
      typeof id,
      "Lechu to dla Ciebie"
    );
    web3.eth.estimateGas({ from: walletAddress.value, gas: 5e6 });
    contract.methods.addPart(walletAddress.value, url, position, id).send({ from: walletAddress.value, gas: 5e6 }).then((result) => {
      console.log(result);
      loader.value = false;
    }).catch((res) => {
      console.log(res);
      loader.value = false;
    });
  };
  const askAi = async (data) => {
    let all = { dalle_input: data };
    console.log(JSON.stringify(all));
    try {
      const response = await fetch("https://hoc38.fly.dev/ai-prompt", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(all)
      });
      console.log("Server response:", response);
      if (response.ok) {
        const responseBody = await response.json();
        console.log("File uploaded successfully. Response body:", responseBody);
        console.log(responseBody);
        return responseBody;
      } else {
        console.error("File upload failed. Status:", response.status);
      }
    } catch (error) {
      console.error("An error occurred during file upload:", error);
    }
  };
  const getTokens = async () => {
    const url = `token-ids?wallet=${walletAddress.value}`;
    console.log(url);
    try {
      const response = await fetch(`https://hoc38.fly.dev/${url}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json"
        }
      });
      if (response.ok) {
        const responseBody = await response.json();
        console.log("File uploaded successfully. Response body:", responseBody);
        return responseBody;
      } else {
        console.error("File upload failed. Status:", response.status);
      }
    } catch (error) {
      console.error("An error occurred during file upload:", error);
    }
  };
  const upload = async (file, nameNft, descriptionNft, indexNft) => {
    const formData = new FormData();
    formData.append("first_art", file);
    try {
      const response = await fetch("https://hoc38.fly.dev/image", {
        method: "POST",
        body: formData
      });
      if (response.ok) {
        const responseBody = await response.json();
        console.log("File uploaded successfully. Response body:", responseBody);
        const contractId = "0x49a985C23CEda09d42AB7e4e3F78718404834b73";
        const data = {
          name: nameNft,
          description: descriptionNft,
          image: responseBody.url,
          position: indexNft
        };
        try {
          console.log(JSON.stringify(data));
          const response2 = await fetch("https://hoc38.fly.dev/metadata", {
            method: "POST",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
          });
          if (response2.ok) {
            const responseBody2 = await response2.json();
            console.log(
              "File uploaded successfully. Response body:",
              responseBody2
            );
            const contractId2 = "0x49a985C23CEda09d42AB7e4e3F78718404834b73";
            console.log(responseBody2);
            safeMintNft(contractId2, contractAbi, responseBody2, indexNft);
          } else {
            console.error("File upload failed. Status:", response2.status);
          }
        } catch (error) {
          console.error("An error occurred during file upload:", error);
        }
      } else {
        console.error("File upload failed. Status:", response.status);
      }
    } catch (error) {
      console.error("An error occurred during file upload:", error);
    }
  };
  const upgrade = async (file, indexNft, tokenId2) => {
    const formData = new FormData();
    formData.append("first_art", file);
    try {
      const response = await fetch("https://hoc38.fly.dev/image", {
        method: "POST",
        body: formData
      });
      if (response.ok) {
        const responseBody = await response.json();
        console.log("File uploaded successfully. Response body:", responseBody);
        const contractId = "0x49a985C23CEda09d42AB7e4e3F78718404834b73";
        const data = {
          image: responseBody.url,
          name: "string",
          description: "string",
          position: indexNft,
          token_id: tokenId2
        };
        console.log(data, "Piotrek");
        try {
          console.log(JSON.stringify(data));
          const response2 = await fetch("https://hoc38.fly.dev/metadata", {
            method: "POST",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
          });
          if (response2.ok) {
            const responseBody2 = await response2.json();
            console.log(
              "File uploaded successfully. Response body:",
              responseBody2
            );
            const contractId2 = "0x49a985C23CEda09d42AB7e4e3F78718404834b73";
            console.log(responseBody2);
            join(contractAbi, responseBody2, indexNft, tokenId2);
          } else {
            console.error("File upload failed. Status:", response2.status);
          }
        } catch (error) {
          console.error("An error occurred during file upload:", error);
        }
      } else {
        console.error("File upload failed. Status:", response.status);
      }
    } catch (error) {
      console.error("An error occurred during file upload:", error);
    }
  };
  return {
    upload,
    upgrade,
    getWeb3,
    getTokens,
    askAi,
    safeMintNft,
    connectWallet,
    join,
    callSmartContract,
    tokenId,
    walletAddress,
    tokens,
    parts
  };
});

export { useWalletStore as u };
//# sourceMappingURL=wallet.store-9b19ef46.mjs.map
