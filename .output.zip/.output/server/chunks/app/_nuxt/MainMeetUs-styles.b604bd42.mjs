const MainMeetUs_vue_vue_type_style_index_0_lang = ".text-cyan_gradient{-webkit-text-fill-color:transparent;background:#4945fc;background:linear-gradient(90deg,#4945fc 1%,#06a2d4 40%);-webkit-background-clip:text}";

const MainMeetUsStyles_b604bd42 = [MainMeetUs_vue_vue_type_style_index_0_lang];

export { MainMeetUsStyles_b604bd42 as default };
//# sourceMappingURL=MainMeetUs-styles.b604bd42.mjs.map
