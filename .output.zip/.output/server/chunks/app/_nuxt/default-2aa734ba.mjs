import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_0 } from './nuxt-link-6bdec6f5.mjs';
import { useSSRContext, defineComponent, ref, mergeProps, unref, withCtx, createVNode, createTextVNode } from 'vue';
import { _ as _export_sfc, u as useState } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderClass, ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrRenderSlot } from 'vue/server-renderer';
import { u as useWalletStore } from './wallet.store-9b19ef46.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'vue3-particles';
import 'web3';

const _imports_0 = "" + buildAssetsURL("logo.e8962df0.svg");
const _imports_1 = "" + buildAssetsURL("metamask.9e279391.svg");
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "CoreHeader",
  __ssrInlineRender: true,
  setup(__props) {
    ref("Connect to wallet");
    const walletId = useState("walletAddress");
    let shortId = ref();
    useWalletStore();
    const scrolled = ref(true);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "w-full flex justify-center" }, _attrs))}><div class="${ssrRenderClass([{
        "backdrop-blur-sm ": unref(scrolled),
        "": !unref(scrolled)
      }, "h-32 container mx-auto w-full bg-inherit w-full flex flex-row items-center justify-between px-8 fixed z-50"])}">`);
      _push(ssrRenderComponent(_component_nuxt_link, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_0)} class="h-16" fill="currentColor" alt="logo"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_0,
                class: "h-16",
                fill: "currentColor",
                alt: "logo"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="space-x-5 flex items-center">`);
      _push(ssrRenderComponent(_component_nuxt_link, {
        to: { path: "/", hash: "#meetUs" },
        class: "py-2 px-4 text-white/80 font-medium"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`AboutUs`);
          } else {
            return [
              createTextVNode("AboutUs")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_nuxt_link, {
        class: "py-2 px-4 text-white/80 font-medium",
        to: { path: "/", hash: "#howItWorks" }
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Documentation`);
          } else {
            return [
              createTextVNode("Documentation")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<button class="${ssrRenderClass([{
        "opacity-0 hidden": unref(walletId),
        "opacity-100": unref(walletId) == void 0
      }, "py-3 px-5 rounded-sm font-medium bg-violet_gradient text-white shadow-blue-800 shadow-xl"])}"> Connect to wallet </button><div class="${ssrRenderClass([{
        "opacity-0 hidden": unref(walletId) == void 0,
        "opacity-100": unref(walletId)
      }, "py-1 px-8 w-fit border rounded-sm flex items-center justify-center duration-500"])}"><img class="w-10 p-2"${ssrRenderAttr("src", _imports_1)}><p class="text-cyan-500">${ssrInterpolate(unref(shortId))}...</p></div></div></div></section>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/core/CoreHeader.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/core/CoreFooter.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_CoreHeader = _sfc_main$2;
  const _component_CoreFooter = __nuxt_component_1;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "mx-auto font-mono" }, _attrs))}>`);
  _push(ssrRenderComponent(_component_CoreHeader, null, null, _parent));
  _push(`<main class="pt-20 bg-black">`);
  ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
  _push(`</main>`);
  _push(ssrRenderComponent(_component_CoreFooter, null, null, _parent));
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/default.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _default = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { _default as default };
//# sourceMappingURL=default-2aa734ba.mjs.map
