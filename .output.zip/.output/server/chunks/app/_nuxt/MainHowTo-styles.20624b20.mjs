const MainHowTo_vue_vue_type_style_index_0_lang = ".text-cyan_gradient{-webkit-text-fill-color:transparent;background:#4945fc;background:linear-gradient(90deg,#4945fc 1%,#06a2d4 40%);-webkit-background-clip:text}";

const MainHowToStyles_20624b20 = [MainHowTo_vue_vue_type_style_index_0_lang];

export { MainHowToStyles_20624b20 as default };
//# sourceMappingURL=MainHowTo-styles.20624b20.mjs.map
