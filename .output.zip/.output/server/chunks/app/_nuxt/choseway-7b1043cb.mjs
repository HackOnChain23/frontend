import { _ as _sfc_main$1 } from './ParticlesComponent-ca732bb7.mjs';
import { _ as __nuxt_component_0 } from './Loader-17c38d82.mjs';
import { _ as __nuxt_component_0$1 } from './nuxt-link-6bdec6f5.mjs';
import { defineComponent, ref, mergeProps, unref, withCtx, createTextVNode, useSSRContext } from 'vue';
import { u as useState, a as useRouter } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderClass, ssrRenderList, ssrRenderAttr } from 'vue/server-renderer';
import { u as useWalletStore } from './wallet.store-9b19ef46.mjs';
import 'tsparticles';
import 'ufo';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'h3';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'vue3-particles';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'klona';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'web3';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "choseway",
  __ssrInlineRender: true,
  setup(__props) {
    const walletId = useState("walletAddress");
    const chosenOption = ref("Dropdown button");
    const listState = ref(false);
    const loader = useState("loader");
    const store = useWalletStore();
    const tokens = useState("tokens");
    useRouter();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ParticlesComponent = _sfc_main$1;
      const _component_Loader = __nuxt_component_0;
      const _component_nuxt_link = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-black h-full w-full" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_ParticlesComponent, null, null, _parent));
      _push(`<section class="w-screen mx-auto container h-[62.5rem] overflow-hidden">`);
      if (unref(loader)) {
        _push(ssrRenderComponent(_component_Loader, { class: "" }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (!unref(walletId)) {
        _push(`<div class="container text-center w-full h-[62.5rem] mx-auto flex items-center justify-center backdrop-blur-sm"><p class="text-4xl h-16 animate-bounce text-cyan_gradient font-bold mb-4 font-mono"> Connect to wallet firstly </p></div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(walletId)) {
        _push(`<div class="container mx-auto w-full h-[40rem] flex p-4 gap-x-8 backdrop-blur-sm mt-40"><div class="w-1/2 h-full p-8 border border-gray-200 rounded-lg flex flex-col justify-center items-center"><h1 class="text-white/90 text-3xl text-center mb-32"> Start a new game, add the first part, and invite others to join in! </h1>`);
        _push(ssrRenderComponent(_component_nuxt_link, {
          to: "/workspace",
          class: "hover:scale-110 flex items-center justify-center text-2xl text-white/90 duration-300 h-20 w-1/2 rounded-sm shadow-sm shadow-blue-500 bg-violet_gradient"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` Start a new game `);
            } else {
              return [
                createTextVNode(" Start a new game ")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div><div class="w-1/2 h-full p-8 border border-gray-200 rounded-lg flex flex-col justify-center items-center"><h1 class="text-white/90 text-3xl text-center"> Join in creating the masterpiece and add something of your own! </h1><p class="text-white/90 text-xl text-center mt-10"> Check availability: </p><div class="relative"><button id="dropdownDefaultButton" data-dropdown-toggle="dropdown" class="text-white w-[21rem] bg-blue-700 mb-2 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-2.5 text-center inline-flex items-center justify-between dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800" type="button">${ssrInterpolate(unref(chosenOption))} <svg class="w-4 h-4 ml-2" aria-hidden="true" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg></button><div id="dropdown" class="${ssrRenderClass([{ flex: unref(listState), hidden: !unref(listState) }, "z-10 absolute top-12 w-[21rem] bg-white flex-col rounded-sm shadow h-auto dark:bg-gray-700"])}">`);
        if (!unref(tokens)) {
          _push(ssrRenderComponent(_component_Loader, { class: "w-full" }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`<ul class="py-2 h-auto text-sm text-gray-700 dark:text-gray-200" aria-labelledby="dropdownDefaultButton"><!--[-->`);
        ssrRenderList(unref(store).tokens, (elem) => {
          _push(`<li class="cursor-pointer space-y-2"><div class="flex justify-between items-center px-4 py-1"><p>${ssrInterpolate(elem.name)}</p><img class="w-8 h-8"${ssrRenderAttr("src", elem.image)}></div></li>`);
        });
        _push(`<!--]--></ul></div></div><button class="hover:scale-110 text-white/90 text-2xl duration-300 h-20 w-1/2 rounded-sm shadow-sm shadow-blue-500 bg-violet_gradient"> Check &amp; Join </button></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</section></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/choseway.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=choseway-7b1043cb.mjs.map
