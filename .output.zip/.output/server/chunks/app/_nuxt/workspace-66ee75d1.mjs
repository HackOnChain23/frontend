import { _ as _sfc_main$3 } from './ParticlesComponent-ca732bb7.mjs';
import { _ as __nuxt_component_0 } from './Loader-17c38d82.mjs';
import { useSSRContext, defineComponent, unref, ref, mergeProps } from 'vue';
import { u as useState } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrRenderClass, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import { u as useWalletStore } from './wallet.store-9b19ef46.mjs';
import 'tsparticles';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'h3';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'ufo';
import 'vue3-particles';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'klona';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'web3';

const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "Workspace",
  __ssrInlineRender: true,
  setup(__props) {
    const photoToUpload = ref();
    const loader = useState("loader");
    const store = useWalletStore();
    const aiInput = ref("");
    const name = ref();
    const description = ref();
    ref();
    const photosToPreview = ref([
      { src: void 0 },
      { src: void 0 },
      { src: void 0 },
      { src: void 0 },
      { src: void 0 },
      { src: void 0 }
    ]);
    const aiState = ref(false);
    ref();
    let photos = [
      "assets/example/1.jpeg",
      "assets/example/2.jpeg",
      "assets/example/3.jpeg",
      "assets/example/4.jpeg"
    ];
    const chosenPhoto = ref("");
    const exampleOutput = ["1", "2", "3", "4", "5", "6"];
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Loader = __nuxt_component_0;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "container mx-auto w-full h-auto backdrop-blur-sm flex" }, _attrs))}>`);
      if (unref(loader)) {
        _push(ssrRenderComponent(_component_Loader, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="h-[62.5rem] w-1/2 p-4"><div class="w-full h-full p-4"><p class="text-white/90 text-left text-2xl"> Upload your block or generate with AI </p><div class="w-full h-[15rem] flex"><div class="h-full w-full flex flex-col justify-center space-y-4 items-start duration-500"><p class="text-white/90 mb-2 text-left"> Select an empty block and add your piece by clicking on it. </p>`);
      if (!unref(store).parts) {
        _push(`<div class="h-auto flex w-full bg-black space-y-4 flex-col"><div class="flex w-full border border-blue-500"><input type="text" class="w-full text-white bg-black p-2" placeholder="Name..."${ssrRenderAttr("value", unref(name))}></div><div class="flex w-full border border-blue-500"><input type="text" class="w-full text-white bg-black p-2" placeholder="Description..."${ssrRenderAttr("value", unref(description))}></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div class="mt-4"><p class="text-white mb-2 text-left"> Feeling empty-headed and lacking ideas? <br>Ask AI, and I&#39;ll generate a few suggestions for you. </p><div class="h-10 flex bg-black border border-blue-500"><input type="text" class="w-full text-white bg-black p-2" placeholder="Type your input here..."${ssrRenderAttr("value", unref(aiInput))}><button class="h-full w-32 hover:scale-110 duration-300 right-0h-10 rounded-sm shadow-sm shadow-blue-500 bg-violet_gradient"> Ask </button></div></div>`);
      if (unref(aiState)) {
        _push(`<p class="text-cyan_gradient mt-4 mb-2 text-center"> There you have four sample photos based on your input. Choose visely </p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="${ssrRenderClass([{ flex: unref(aiState), hidden: !unref(aiState) }, "flex items-center justify-center"])}"><div class="w-6/12 h-full flex flex-wrap items-center justify-center"><!--[-->`);
      ssrRenderList(unref(photos), (photo, photoIndex) => {
        _push(`<div class="w-1/2 flex items-center justify-center"><img class="${ssrRenderClass([{
          "border-4 border-blue-500 scale-110": unref(chosenPhoto) == unref(photos)[photoIndex]
        }, "hover:scale-150 duration-300 h-[12rem] w-[12rem]"])}"${ssrRenderAttr("src", photo)}></div>`);
      });
      _push(`<!--]--></div><div class="3/12 hidden p-4 flex flex-col space-y-1 items-center justify-center"><button class="hover:scale-110 duration-300 h-20 w-full text-sm rounded-sm shadow-sm shadow-blue-500 bg-violet_gradient"> Top Left </button><button class="hover:scale-110 duration-300 h-20 w-full text-sm rounded-sm shadow-sm shadow-blue-500 bg-violet_gradient"> Top Right </button><button class="hover:scale-110 duration-300 h-20 w-full text-sm rounded-sm shadow-sm shadow-blue-500 bg-violet_gradient"> Bottom Left </button><button class="hover:scale-110 duration-300 h-20 w-full text-sm rounded-sm shadow-sm shadow-blue-500 bg-violet_gradient"> Bottom Right </button></div></div></div></div><div class="h-[60rem] flex items-center justify-around w-1/2 p-4 flex-col"><div class="w-10/12 h-5/6 border border-gray-500"><div id="photo" class="flex flex-wrap w-full h-full"><!--[-->`);
      ssrRenderList(exampleOutput, (photo, index) => {
        _push(`<div class="w-1/2 h-1/3 border border-gray-500 flex justify-center items-center">`);
        if (unref(chosenPhoto).length == 0) {
          _push(`<form enctype="multipart/form-data"><label${ssrRenderAttr("for", photo)} class="${ssrRenderClass([{ hidden: unref(photoToUpload) }, "px-10 w-auto h-auto cursor-pointer hover:text-white py-4 rounded-sm shadow-sm shadow-blue-500 bg-violet_gradient"])}">${ssrInterpolate(index + 1)}</label><input${ssrRenderAttr("id", photo)} type="file" class="hidden inputButton"></form>`);
        } else {
          _push(`<!---->`);
        }
        if (unref(chosenPhoto).length > 0) {
          _push(`<form><div class="${ssrRenderClass([{ hidden: unref(photoToUpload) }, "px-10 w-auto animate-bounce h-auto cursor-pointer hover:text-white py-4 rounded-sm shadow-sm shadow-blue-500 bg-violet_gradient"])}">${ssrInterpolate(index + 1)}</div></form>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<div class="${ssrRenderClass([{
          flex: unref(photosToPreview)[index].src,
          hidden: unref(photosToPreview)[index].src == void 0
        }, "h-full w-full justify-center items-center"])}"><div class="w-full h-full flex items-center p-4 justify-center"><p class="hidden">Preview</p><div class="w-full h-full border-2 relative border-blue-500 rounded-lg"><div class="absolute w-8 h-8 cursor-pointer rounded-full bg-white text-black font-bold flex items-center justify-center right-0 top-0"> X </div><img class="w-full h-full rounded-lg object-cover"${ssrRenderAttr("src", unref(photosToPreview)[index].src)}></div></div></div></div>`);
      });
      _push(`<!--]--></div></div><form enctype="multipart/form-data"><div class="hover:scale-110 cursor-pointer flex justify-center items-center duration-300 h-16 text-xl text-white w-80 text-sm rounded-sm shadow-sm shadow-blue-500 bg-violet_gradient"> Apply </div></form></div></section>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Workspace.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "WorkspaceContinue",
  __ssrInlineRender: true,
  setup(__props) {
    const photoToUpload = ref();
    const loader = useState("loader");
    const store = useWalletStore();
    const aiInput = ref("");
    useState("tokenid");
    ref();
    const photosToPreview = ref([
      { src: void 0 },
      { src: void 0 },
      { src: void 0 },
      { src: void 0 },
      { src: void 0 },
      { src: void 0 }
    ]);
    const aiState = ref(false);
    ref();
    let photos = [
      "assets/example/1.jpeg",
      "assets/example/2.jpeg",
      "assets/example/3.jpeg",
      "assets/example/4.jpeg"
    ];
    const chosenPhoto = ref("");
    const exampleOutput = ["1", "2", "3", "4", "5", "6"];
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Loader = __nuxt_component_0;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "container mx-auto w-full h-auto backdrop-blur-sm flex" }, _attrs))}>`);
      if (unref(loader)) {
        _push(ssrRenderComponent(_component_Loader, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="h-[62.5rem] w-1/2 p-4"><div class="w-full h-full p-4"><p class="text-white/90 text-left text-2xl"> Upload your block or generate with AI </p><div class="w-full h-[15rem] flex"><div class="h-full w-full flex flex-col justify-center space-y-4 items-start duration-500"><p class="text-white/90 mb-2 text-left"> Select an empty block and add your piece by clicking on it. </p></div></div><div class="mt-4"><p class="text-white mb-2 text-left"> Feeling empty-headed and lacking ideas? <br>Ask AI, and I&#39;ll generate a few suggestions for you. </p><div class="h-10 flex bg-black border border-blue-500"><input type="text" class="w-full text-white bg-black p-2" placeholder="Type your input here..."${ssrRenderAttr("value", unref(aiInput))}><button class="h-full w-32 hover:scale-110 duration-300 right-0h-10 rounded-sm shadow-sm shadow-blue-500 bg-violet_gradient"> Ask </button></div></div>`);
      if (unref(aiState)) {
        _push(`<p class="text-cyan_gradient mt-4 mb-2 text-center"> There you have four sample photos based on your input. Choose visely </p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="${ssrRenderClass([{ flex: unref(aiState), hidden: !unref(aiState) }, "flex items-center justify-center"])}"><div class="w-6/12 h-full flex flex-wrap items-center justify-center"><!--[-->`);
      ssrRenderList(unref(photos), (photo, photoIndex) => {
        _push(`<div class="w-1/2 flex items-center justify-center"><img class="${ssrRenderClass([{
          "border-4 border-blue-500 scale-110": unref(chosenPhoto) == unref(photos)[photoIndex]
        }, "hover:scale-150 duration-300 h-[12rem] w-[12rem]"])}"${ssrRenderAttr("src", photo)}></div>`);
      });
      _push(`<!--]--></div><div class="3/12 hidden p-4 flex flex-col space-y-1 items-center justify-center"><button class="hover:scale-110 duration-300 h-20 w-full text-sm rounded-sm shadow-sm shadow-blue-500 bg-violet_gradient"> Top Left </button><button class="hover:scale-110 duration-300 h-20 w-full text-sm rounded-sm shadow-sm shadow-blue-500 bg-violet_gradient"> Top Right </button><button class="hover:scale-110 duration-300 h-20 w-full text-sm rounded-sm shadow-sm shadow-blue-500 bg-violet_gradient"> Bottom Left </button><button class="hover:scale-110 duration-300 h-20 w-full text-sm rounded-sm shadow-sm shadow-blue-500 bg-violet_gradient"> Bottom Right </button></div></div></div></div><div class="h-[60rem] flex items-center justify-around w-1/2 p-4 flex-col"><div class="w-10/12 h-5/6 border border-gray-500"><div id="photo" class="flex flex-wrap w-full h-full"><!--[-->`);
      ssrRenderList(exampleOutput, (photo, index) => {
        _push(`<div class="w-1/2 h-1/3 border border-gray-500 flex justify-center items-center">`);
        if (unref(chosenPhoto).length == 0) {
          _push(`<form enctype="multipart/form-data">`);
          if (unref(photosToPreview)[index].src == void 0 && unref(aiState) == false) {
            _push(`<label${ssrRenderAttr("for", photo)} class="${ssrRenderClass([{ hidden: unref(photoToUpload) }, "px-10 w-auto h-auto cursor-pointer hover:text-white py-4 rounded-sm shadow-sm shadow-blue-500 bg-violet_gradient"])}">${ssrInterpolate(index + 1)}</label>`);
          } else {
            _push(`<!---->`);
          }
          _push(`<input${ssrRenderAttr("id", photo)} type="file" class="hidden inputButton"></form>`);
        } else {
          _push(`<!---->`);
        }
        if (unref(photosToPreview)[index].src == void 0 && unref(aiState) == true) {
          _push(`<form><div class="${ssrRenderClass([{ hidden: unref(photoToUpload) }, "px-10 w-auto animate-bounce h-auto cursor-pointer hover:text-white py-4 rounded-sm shadow-sm shadow-blue-500 bg-violet_gradient"])}">${ssrInterpolate(index + 1)}</div></form>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<div class="${ssrRenderClass([{
          flex: unref(photosToPreview)[index].src,
          hidden: unref(photosToPreview)[index].src == void 0
        }, "h-full w-full justify-center items-center"])}"><div class="w-full h-full flex items-center p-4 justify-center"><p class="hidden">Preview</p><div class="w-full h-full border-2 relative border-blue-500 rounded-lg">`);
        if (!unref(store).parts.includes(unref(photosToPreview)[index].src)) {
          _push(`<div class="absolute w-8 h-8 cursor-pointer rounded-full bg-white text-black font-bold flex items-center justify-center right-0 top-0"> X </div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<img class="w-full h-full rounded-lg object-cover"${ssrRenderAttr("src", unref(photosToPreview)[index].src)}></div></div></div></div>`);
      });
      _push(`<!--]--></div></div><form enctype="multipart/form-data"><div class="hover:scale-110 cursor-pointer flex justify-center items-center duration-300 h-16 text-xl text-white w-80 text-sm rounded-sm shadow-sm shadow-blue-500 bg-violet_gradient"> Apply </div></form></div></section>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/WorkspaceContinue.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "workspace",
  __ssrInlineRender: true,
  setup(__props) {
    const walletId = useState("walletAddress");
    const store = useWalletStore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ParticlesComponent = _sfc_main$3;
      const _component_Workspace = _sfc_main$2;
      const _component_WorkspaceContinue = _sfc_main$1;
      _push(`<section${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_ParticlesComponent, null, null, _parent));
      if (!unref(walletId)) {
        _push(`<div class="container text-center w-full h-[62.5rem] mx-auto flex items-center justify-center backdrop-blur-sm"><p class="text-4xl h-16 animate-bounce text-cyan_gradient font-bold mb-4 font-mono"> Connect to wallet firstly </p></div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(walletId)) {
        _push(`<div>`);
        if (!unref(store).parts) {
          _push(ssrRenderComponent(_component_Workspace, null, null, _parent));
        } else {
          _push(`<!---->`);
        }
        if (unref(store).parts) {
          _push(ssrRenderComponent(_component_WorkspaceContinue, null, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</section>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/workspace.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=workspace-66ee75d1.mjs.map
