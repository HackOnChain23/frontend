import { _ as _sfc_main$5 } from './ParticlesComponent-ca732bb7.mjs';
import { _ as __nuxt_component_0 } from './nuxt-link-6bdec6f5.mjs';
import { useSSRContext, defineComponent, ref, mergeProps, unref, withCtx, createTextVNode } from 'vue';
import { _ as _export_sfc, u as useState } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderClass, ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderAttr } from 'vue/server-renderer';
import { u as useWalletStore } from './wallet.store-9b19ef46.mjs';
import 'tsparticles';
import 'ufo';
import 'ofetch';
import 'hookable';
import 'unctx';
import 'h3';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'vue3-particles';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'unenv/runtime/fetch/index';
import 'scule';
import 'klona';
import 'ohash';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import 'web3';

const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "MainHero",
  __ssrInlineRender: true,
  setup(__props) {
    const walletId = useState("walletAddress");
    const scrolled = ref(true);
    useWalletStore();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_nuxt_link = __nuxt_component_0;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "h-[30rem] container mx-auto bg-transparent pointer-event-none" }, _attrs))}><div class="${ssrRenderClass([{
        "opacity-0 invisible": unref(scrolled),
        "opacity-100, visible": !unref(scrolled)
      }, "w-full h-auto bg-transparent pointer-event-none fixed duration-500 top-0"])}"><div class="relative -top-10"><div class="w-1/4 fixed h-40 blur-[50px] bg-white/80 ponter-event-none z-30 rounded-b-full mx-auto left-0 right-0"></div><div class="w-2/4 fixed top-0 h-1/3 z-20 blur-[120px] ponter-event-none bg-cyan-500/60 rounded-b-full mx-auto left-0 right-0"></div><div class="w-11/12 fixed top-0 h-1/2 blur-[160px] ponter-event-none z-10 bg-violet-900 rounded-b-full mx-auto left-0 right-0"></div></div></div><div class="w-full h-auto pointer-event-auto bg-transparent drop-shadow-2xl flex items-center justify-center flex-col z-50 pt-40"><h1 class="text-6xl h-32 z-10 font-bold tracking-[-.3rem] text-white mb-4 text-stroke text-center text-white"> One Collective Masterpiece<br>Born of Six Creators </h1><h2 class="text-xl font-thin text-white tracking-[-.05rem]"> Artistic concept based on blockchain. </h2><div class="h-40"><div class="w-[40rem] shadow-blue-700 p-0.5 mt-10 rounded-sm flex justify-center items-center hover:border-gray-200 duration-300">`);
      if (!unref(walletId)) {
        _push(`<p class="text-4xl h-16 text-cyan_gradient font-bold text-white mb-4 text-white font-mono"> Connect to wallet firstly </p>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(walletId)) {
        _push(ssrRenderComponent(_component_nuxt_link, {
          to: "/choseway",
          class: "w-full flex justify-center items-center box-border h-12 text-white bg-violet_gradient rounded-sm text-base hover:text-lg duration-300"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` Join `);
            } else {
              return [
                createTextVNode(" Join ")
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div></section>`);
    };
  }
});
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MainHero.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const _sfc_main$3 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  _push(`<section${ssrRenderAttrs(mergeProps({ class: "container mx-auto h-auto backdrop-blur-sm p-6 mt-10" }, _attrs))}><h1 class="text-4xl h-16 text-cyan_gradient font-bold text-white mb-4 text-white font-mono"> What it is? </h1><p class="text-white/80 font-mono text-md"> Block Artistry is an innovative, digital multiplayer game that merges the world of art, blockchain, and NFTs. Here, every player contributes to a shared artistic endeavor, adding their creative block to a common 2x3 grid. This forms a constantly evolving digital canvas where individual creativity and collective vision come together. <br><br> At the beginning of each round, the 2x3 grid starts blank, a metaphorical blank canvas waiting for artists to bring it to life. Players are randomly assigned a turn to place their block, each block carrying a unique design, pattern, or color according to the artist&#39;s taste. <br> This process continues in a cyclic manner until the 2x3 grid is complete. The resulting artwork is a harmonious or sometimes eclectic blend of the participating artists&#39; creativity. It&#39;s a piece that holds a part of every contributor, each block a testament to an individual&#39;s imagination and style. <br> Once the grid is completed, it is then converted into a Non-Fungible Token (NFT) and put up for auction. The unique NFT serves as proof of authenticity and ownership of this digital art piece. The proceeds from the auction are divided equally amongst the contributing artists, rewarding them for their collaboration.<br><br> Block Artistry is not just a game but a celebration of creativity and community. It&#39;s a testament to how diverse artistic voices can come together to create something unique, valuable, and truly one of a kind. A blend of art, gaming, and crypto - Block Artistry represents a new age of digital creativity. </p></section>`);
}
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MainDescription.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "MainHowTo",
  __ssrInlineRender: true,
  setup(__props) {
    const blocks = [
      {
        title: "Make or Join a Round",
        description: "Start the game by either creating a new round or joining an existing one. Each round begins with a blank 2x3 grid that serves as the canvas for you and your fellow players to create a collective artwork."
      },
      {
        title: "Design Your Block",
        description: "Channel your creativity to design your block with a unique pattern, design, or color. This block represents your individual artistic contribution to the shared artwork."
      },
      {
        title: "Place Your Block",
        description: "Once you're satisfied with your design, place your block on any available spot on the grid. The game moves forward in a cyclic manner, with each player adding their block in turns."
      },
      {
        title: "Invite a Friend",
        description: "Share the fun! Invite your friends to join the round and contribute their own blocks to the artwork. Their unique designs will add to the diversity and richness of the final piece."
      },
      {
        title: "Witness the Transformation",
        description: "Observe as the grid transforms from a blank canvas to a unique collaborative artwork. Every filled 2x3 grid becomes an exclusive piece of art, the result of the collective creativity of all the players involved."
      },
      {
        title: "Auction and Rewards",
        description: "When the grid is filled and the artwork is complete, it is transformed into a Non-Fungible Token (NFT) and put up for auction. The proceeds from the auction are equally divided among all the contributing artists, rewarding each for their part in the collaborative effort. Enjoy the thrill of seeing your creativity rewarded!"
      }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({
        id: "howItWorks",
        class: "container mx-auto backdrop-blur-sm h-auto p-6 pt-10"
      }, _attrs))}><h1 class="text-4xl w-auto h-16 text-cyan_gradient font-bold mb-4 font-mono"> How it works </h1><div class="flex flex-wrap"><!--[-->`);
      ssrRenderList(blocks, (block, blockIndex) => {
        _push(`<div class="h-[25rem] w-1/3 text-white p-2"><div class="border border-gray-500 rounded-md w-full h-full p-4 backdrop-blur-sm space-y-8"><p class="text-white absolute text-[20rem] font-bold bottom-0 right-0 leading-[16rem] text-cyan_gradient opacity-20">${ssrInterpolate(blockIndex + 1)}</p><h2 class="text-2xl text-cyan_gradient z-20">${ssrInterpolate(block.title)}</h2><p>${ssrInterpolate(block.description)}</p></div></div>`);
      });
      _push(`<!--]--></div></section>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MainHowTo.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "MainMeetUs",
  __ssrInlineRender: true,
  setup(__props) {
    const devData = [
      {
        role: "Backend Dev",
        name: "Szacilowski",
        photo: "/assets/ourPhotos/szacilowski.jpg"
      },
      {
        role: "Frontend Dev",
        name: "Paluch77",
        photo: "/assets/ourPhotos/paluch.jpeg"
      },
      {
        role: "Blockchain Dev",
        name: "Lechu13",
        photo: "/assets/ourPhotos/lechu.jpeg"
      },
      {
        role: "Backend Dev",
        name: "Sitletto",
        photo: "/assets/ourPhotos/mateusz.jpg"
      }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({
        id: "meetUs",
        class: "container mx-auto h-auto backdrop-blur-sm p-6 mt-10 mb-40"
      }, _attrs))}><h1 class="text-4xl h-16 text-cyan_gradient font-bold text-white mb-4 text-white font-mono"> Meet us </h1><div class="w-full h-auto divide-x flex divide-transparent items-center justify-center text-center"><!--[-->`);
      ssrRenderList(devData, (elem, elemIndex) => {
        _push(`<div class="w-full h-80 px-8"><img class="shadow-blue-500 shadow-xl mb-3 w-full h-80 object-center object-cover"${ssrRenderAttr("src", elem.photo)}><p class="text-lg text-white">${ssrInterpolate(elem.role)}</p><p class="text-white text-cyan_gradient">${ssrInterpolate(elem.name)}</p></div>`);
      });
      _push(`<!--]--></div></section>`);
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MainMeetUs.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_ParticlesComponent = _sfc_main$5;
  const _component_MainHero = _sfc_main$4;
  const _component_MainDescription = __nuxt_component_2;
  const _component_MainHowTo = _sfc_main$2;
  const _component_MainMeetUs = _sfc_main$1;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "bg-black" }, _attrs))}>`);
  _push(ssrRenderComponent(_component_ParticlesComponent, { class: "" }, null, _parent));
  _push(ssrRenderComponent(_component_MainHero, null, null, _parent));
  _push(ssrRenderComponent(_component_MainDescription, null, null, _parent));
  _push(ssrRenderComponent(_component_MainHowTo, null, null, _parent));
  _push(ssrRenderComponent(_component_MainMeetUs, null, null, _parent));
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { index as default };
//# sourceMappingURL=index-210bf4aa.mjs.map
