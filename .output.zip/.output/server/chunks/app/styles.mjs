const interopDefault = r => r.default || r || [];
const styles = {
  "components/MainDescription.vue": () => import('./_nuxt/MainDescription-styles.74cac715.mjs').then(interopDefault),
  "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": () => import('./_nuxt/error-404-styles.f4b6ac90.mjs').then(interopDefault),
  "node_modules/.pnpm/@nuxt+ui-templates@1.1.1/node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": () => import('./_nuxt/error-500-styles.af9750fa.mjs').then(interopDefault),
  "components/MainMeetUs.vue": () => import('./_nuxt/MainMeetUs-styles.b604bd42.mjs').then(interopDefault),
  "components/MainHowTo.vue": () => import('./_nuxt/MainHowTo-styles.20624b20.mjs').then(interopDefault),
  "components/core/CoreHeader.vue": () => import('./_nuxt/CoreHeader-styles.abc22f7c.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
