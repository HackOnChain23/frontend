const _virtual__headStatic = {"headTags":"<meta charset=\"utf-8\">\n<title>PSPLS Test Project</title>\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<meta name=\"description\" content=\"content\">\n<link rel=\"dns-prefetch\" href=\"https://fonts.gstatic.com/\">\n<link rel=\"preconnect\" href=\"https://fonts.gstatic.com/\" crossorigin=\"anonymous\">\n<link rel=\"preconnect\" href=\"https://fonts.googleapis.com/\">\n<link data-hid=\"gf-style\" rel=\"stylesheet\" href=\"https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap\">","bodyTags":"","bodyTagsOpen":"","htmlAttrs":"","bodyAttrs":""};

export { _virtual__headStatic as default };
//# sourceMappingURL=_virtual_head-static.mjs.map
